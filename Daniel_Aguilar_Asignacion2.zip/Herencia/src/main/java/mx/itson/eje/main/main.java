
package mx.itson.eje.main;

import mx.itson.eje.entidades.LG;
import mx.itson.eje.entidades.Samsung;
import mx.itson.eje.entidades.Whirpool;

/**
 * En esta clase main importamos los metodos para imprimirlos
 * @author geniuslab
 */
public class main {

    public static void main(String[] args) {

        /*
          Aqui damos y recivimos los valores con getters y setters
        */
        Samsung smg = new Samsung();
        smg.setMarca("Samsung");
        smg.setPrecio(16000);
        smg.setPeso(32);
        smg.setVoltaje("VOLTAJE_110");
        
        System.out.println("Marca: "+smg.getMarca()+ 
                           "\n Precio: "+smg.getPrecio()+
                           "\n Peso: "+smg.getPeso()+
                           "\n Voltaje: "+smg.getVoltaje());
        
        LG lg = new LG();
        lg.setMarca("LG");
        lg.setPrecio(12000);
        lg.setPeso(32);
        lg.setVoltaje("VOLTAJE_220");
        
        System.out.println("");
        System.out.println("Marca: "+lg.getMarca()+ 
                           "\n Precio: "+lg.getPrecio()+
                           "\n Peso: "+lg.getPeso()+
                           "\n Voltaje: "+lg.getVoltaje());
        
        Whirpool w = new Whirpool();
        w.setMarca("Whirlpool");
        w.setPrecio(12000);
        w.setPeso(32);
        w.setVoltaje("VOLTAJE_380");
        
        System.out.println("");
        System.out.println("Marca: "+w.getMarca()+ 
                           "\n Precio: "+w.getPrecio()+
                           "\n Peso: "+w.getPeso()+
                           "\n Voltaje: "+w.getVoltaje());
    }
}
