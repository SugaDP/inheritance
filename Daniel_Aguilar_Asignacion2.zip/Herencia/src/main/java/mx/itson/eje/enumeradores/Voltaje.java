
package mx.itson.eje.enumeradores;

/**
 *
 * @author geniuslab
 */
public enum Voltaje {
    
    /*
    En este enum colocamos los diferentes voltajes que tendran
    las lavadoras
    */
   VOLTAJE_110, VOLTAJE_220, VOLTAJE_380
}
