
package mx.itson.eje.entidades;

import mx.itson.eje.enumeradores.Voltaje;

/**
 * Esta es la clase padre que le dara atrivutos 
 * a las diferentes lavadoras en el mercado 
 * @author geniuslab
 */
public class Lavadora {

    private String color;
    private String voltaje;
    /**
     * @return the color
     * Usamos los metodos para despues poder sus atributos
     */
    public String getColor() {
        return color;
    }

    /**
     * @param color the color to set
     */
    public void setColor(String color) {
        this.color = color;
    }

    /**
     * @return the voltaje
     */
    public String getVoltaje() {
        return voltaje;
    }

    /**
     * @param voltaje the voltaje to set
     */
    public void setVoltaje(String voltaje) {
        this.voltaje = voltaje;
    }
}
